"""Local, tamper-evident 72-hour trial state for Speakeasy."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path


TRIAL_HOURS = 72
ROLLBACK_TOLERANCE = timedelta(minutes=5)
_SIGNING_KEY = b"Speakeasy-ALW-3-day-trial-v1-2026"


@dataclass(frozen=True)
class TrialStatus:
    allowed: bool
    state: str
    started_at: datetime | None = None
    expires_at: datetime | None = None
    remaining: timedelta = timedelta(0)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _state_path() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    if not base:
        base = str(Path.home() / "AppData" / "Local")
    return Path(base) / "AveryLogicWorks" / "Speakeasy" / "trial.json"


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _signature(payload: dict[str, str]) -> str:
    body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(_SIGNING_KEY, body, hashlib.sha256).hexdigest()


def _write_record(path: Path, payload: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    document = {**payload, "signature": _signature(payload)}
    fd, temp_name = tempfile.mkstemp(prefix="trial-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(document, handle, sort_keys=True)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.remove(temp_name)


def _read_record(path: Path) -> dict[str, str]:
    with path.open("r", encoding="utf-8") as handle:
        document = json.load(handle)
    signature = document.pop("signature")
    if not hmac.compare_digest(signature, _signature(document)):
        raise ValueError("invalid trial signature")
    return document


def inspect_trial(now: datetime | None = None, path: Path | None = None) -> TrialStatus:
    """Return trial status without starting a new trial."""
    now = (now or _utc_now()).astimezone(timezone.utc)
    path = path or _state_path()
    if not path.exists():
        return TrialStatus(False, "not_started")

    try:
        record = _read_record(path)
        started_at = _parse(record["started_at"])
        expires_at = _parse(record["expires_at"])
        last_seen_at = _parse(record["last_seen_at"])
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
        return TrialStatus(False, "invalid")

    if now + ROLLBACK_TOLERANCE < last_seen_at:
        return TrialStatus(False, "clock_rollback", started_at, expires_at)

    if now >= expires_at:
        return TrialStatus(False, "expired", started_at, expires_at)

    record["last_seen_at"] = _iso(max(now, last_seen_at))
    try:
        _write_record(path, record)
    except OSError:
        return TrialStatus(False, "storage_error", started_at, expires_at)

    return TrialStatus(True, "active", started_at, expires_at, expires_at - now)


def start_trial(now: datetime | None = None, path: Path | None = None) -> TrialStatus:
    """Start the trial only if no trial record exists."""
    now = (now or _utc_now()).astimezone(timezone.utc)
    path = path or _state_path()
    if path.exists():
        return inspect_trial(now, path)

    expires_at = now + timedelta(hours=TRIAL_HOURS)
    record = {
        "product": "Speakeasy",
        "version": "trial-v1",
        "started_at": _iso(now),
        "expires_at": _iso(expires_at),
        "last_seen_at": _iso(now),
    }
    try:
        _write_record(path, record)
    except OSError:
        return TrialStatus(False, "storage_error", now, expires_at)
    return TrialStatus(True, "active", now, expires_at, expires_at - now)


def format_remaining(remaining: timedelta) -> str:
    total_minutes = max(0, int(remaining.total_seconds() // 60))
    days, remainder = divmod(total_minutes, 24 * 60)
    hours, minutes = divmod(remainder, 60)
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"
