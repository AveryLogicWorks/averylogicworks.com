@echo off
cd /d "%~dp0"
pythonw sentinel_tts_reader.py 2>nul
if errorlevel 1 (
    echo pythonw not found or failed, trying python with console...
    python sentinel_tts_reader.py
)
