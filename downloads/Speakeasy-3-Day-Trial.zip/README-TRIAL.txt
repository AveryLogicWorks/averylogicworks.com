SPEAKEASY — FREE 3-DAY TRIAL
================================

What this is
------------
This is the free trial edition of Speakeasy by Avery Logic Works. It provides
the full Speakeasy experience for 72 consecutive hours after you start it.
There is no charge, no credit card, and no automatic renewal.

Windows requirements
--------------------
1. Windows 10 or newer.
2. Python 3 installed and available as "python" on your PATH.
3. An internet connection on first setup so Speakeasy can install its small
   Python support packages. It does not download, host, or purchase voices.
   Speech uses only the SAPI voices already installed in Windows.

How to start
------------
1. Extract this ZIP to a normal folder. Do not run it inside the ZIP preview.
2. Double-click "Launch Speakeasy.bat".
3. Choose Yes when asked to start your free three-day trial.
4. If Windows asks for permission to install Python packages, allow it.

The trial begins only when you choose Yes. Closing and reopening Speakeasy does
not pause or reset the 72-hour period.

Buying the full version
-----------------------
The paid version is a separate unrestricted download. Purchase it here:
https://averylogicworks.com/programs.html#speakeasy-purchase

Support
-------
https://averylogicworks.com/contact.html
