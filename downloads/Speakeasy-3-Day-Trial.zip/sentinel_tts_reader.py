import subprocess
import sys
import threading
import time
import webbrowser
import tkinter as tk
from functools import partial
from tkinter import messagebox, ttk

from trial_license import format_remaining, inspect_trial, start_trial


PURCHASE_URL = "https://averylogicworks.com/programs.html#speakeasy-purchase"


def ensure_deps():
    dependencies = {
        "pystray": "pystray",
        "Pillow": "PIL",
        "keyboard": "keyboard",
        "pyperclip": "pyperclip",
        "pyttsx3": "pyttsx3",
    }
    missing = []
    for package, module in dependencies.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    if missing:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing, "-q"])


ensure_deps()

import keyboard
import pyperclip
import pystray
import pyttsx3
from PIL import Image, ImageDraw


class SpeakeasyTTS:
    def __init__(self, trial_status):
        self.root = tk.Tk()
        self.root.title("Speakeasy TTS Reader")
        self.root.geometry("700x520")
        self.root.configure(bg="#0f0f1a")
        self.root.protocol("WM_DELETE_WINDOW", self.hide_to_tray)
        self.root.withdraw()

        self.trial_status = trial_status
        self.is_speaking = False
        self.tray_icon = None
        self._engine = None
        self._engine_lock = threading.Lock()
        self._voice_map = {}
        self._current_voice_id = None
        self._current_voice_name = "Windows default"

        self.build_ui()
        self.refresh_voices()
        self.setup_tray()
        self.setup_hotkey()
        self.update_trial_status()

    def create_icon_image(self):
        image = Image.new("RGBA", (64, 64), (15, 15, 26, 255))
        draw = ImageDraw.Draw(image)
        draw.ellipse([4, 4, 60, 60], fill=(0, 255, 170, 255))
        return image

    def _windows_voices(self):
        engine = pyttsx3.init(driverName="sapi5")
        try:
            return [(voice.name or voice.id, voice.id) for voice in engine.getProperty("voices")]
        finally:
            engine.stop()

    def refresh_voices(self):
        try:
            voices = self._windows_voices()
        except Exception as error:
            voices = []
            self.status.config(text=f"Could not read Windows voices: {error}", fg="#e74c3c")
        self._voice_map = {name: voice_id for name, voice_id in voices}
        names = list(self._voice_map)
        self.voice_combo["values"] = names
        if names:
            selected = self.voice_var.get()
            if selected not in self._voice_map:
                selected = names[0]
                self.voice_var.set(selected)
            self._current_voice_name = selected
            self._current_voice_id = self._voice_map[selected]
            self.status.config(text=f"Ready: {selected}", fg="#00ffaa")
        elif not self.status.cget("text").startswith("Could not"):
            self.status.config(text="No Windows speech voices were found.", fg="#e74c3c")
        self.update_tray_menu()

    def on_voice_select(self, event=None):
        selected = self.voice_var.get()
        if selected in self._voice_map:
            self._current_voice_name = selected
            self._current_voice_id = self._voice_map[selected]
            self.status.config(text=f"Ready: {selected}", fg="#00ffaa")
            self.update_tray_menu()

    def _tray_select_voice(self, voice_name, icon, item):
        def select():
            self.voice_var.set(voice_name)
            self.on_voice_select()
        self.root.after(0, select)

    def make_tray_menu(self):
        voice_items = [
            pystray.MenuItem(
                name,
                partial(self._tray_select_voice, name),
                checked=lambda item, n=name: n == self._current_voice_name,
            )
            for name in self._voice_map
        ]
        return pystray.Menu(
            pystray.MenuItem("Stop", self._tray_stop),
            pystray.MenuItem("Read Clipboard", self._tray_read_clipboard),
            pystray.MenuItem("Windows Voices", pystray.Menu(*voice_items)),
            pystray.MenuItem("Show Window", self.show_ui),
            pystray.MenuItem("Buy Speakeasy", lambda icon, item: webbrowser.open(PURCHASE_URL)),
            pystray.MenuItem("Exit", self.exit_app),
        )

    def setup_tray(self):
        self.tray_icon = pystray.Icon(
            "Speakeasy", self.create_icon_image(), "Speakeasy TTS", self.make_tray_menu()
        )
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

    def update_tray_menu(self):
        if self.tray_icon:
            self.tray_icon.menu = self.make_tray_menu()
            self.tray_icon.title = f"Speakeasy - {self._current_voice_name}"
            self.tray_icon.update_menu()

    def setup_hotkey(self):
        keyboard.add_hotkey("ctrl+shift+space", self.on_hotkey)

    def on_hotkey(self):
        if self.is_speaking:
            self._do_stop()
            return
        text = self.get_selected_text()
        if text and text.strip():
            self.speak_text(text.strip())

    def get_selected_text(self):
        try:
            old = pyperclip.paste()
            keyboard.send("ctrl+c")
            time.sleep(0.15)
            copied = pyperclip.paste()
            return copied or old
        except Exception:
            return None

    def _tray_stop(self, icon, item):
        self._do_stop()

    def _tray_read_clipboard(self, icon, item):
        text = pyperclip.paste()
        if text and text.strip():
            self.speak_text(text.strip())
        elif self.tray_icon:
            self.tray_icon.notify("Clipboard is empty.", "Speakeasy")

    def build_ui(self):
        tk.Label(
            self.root, text="Speakeasy TTS Reader", font=("Segoe UI", 18, "bold"),
            bg="#0f0f1a", fg="#00ffaa"
        ).pack(pady=10)
        trial_frame = tk.Frame(self.root, bg="#0f0f1a")
        trial_frame.pack(fill=tk.X, padx=15)
        self.trial_label = tk.Label(
            trial_frame, text="3-day trial", font=("Segoe UI", 10, "bold"),
            bg="#0f0f1a", fg="#f1c40f"
        )
        self.trial_label.pack(side=tk.LEFT)
        tk.Button(
            trial_frame, text="Buy Speakeasy", command=lambda: webbrowser.open(PURCHASE_URL),
            bg="#00ffaa", fg="#0f0f1a", relief=tk.FLAT, cursor="hand2"
        ).pack(side=tk.RIGHT)
        tk.Label(
            self.root,
            text="Paste text and press Speak. F5=Speak, Esc=Stop, Ctrl+Shift+Space=Read Selection",
            font=("Segoe UI", 10), bg="#0f0f1a", fg="#a0a0a0"
        ).pack()

        voice_frame = tk.Frame(self.root, bg="#0f0f1a")
        voice_frame.pack(fill=tk.X, padx=15, pady=8)
        tk.Label(
            voice_frame, text="Windows voice:", font=("Segoe UI", 10, "bold"),
            bg="#0f0f1a", fg="#e0e0e0"
        ).pack(side=tk.LEFT)
        self.voice_var = tk.StringVar()
        self.voice_combo = ttk.Combobox(
            voice_frame, textvariable=self.voice_var, state="readonly", width=42
        )
        self.voice_combo.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        self.voice_combo.bind("<<ComboboxSelected>>", self.on_voice_select)
        tk.Button(
            voice_frame, text="Refresh", command=self.refresh_voices,
            bg="#34495e", fg="#ffffff", relief=tk.FLAT, cursor="hand2"
        ).pack(side=tk.LEFT, padx=2)

        self.text_box = tk.Text(
            self.root, wrap=tk.WORD, font=("Segoe UI", 12), bg="#161b2e",
            fg="#e8e8e8", insertbackground="#00ffaa", relief=tk.FLAT,
            padx=10, pady=10, height=14
        )
        self.text_box.pack(fill=tk.BOTH, expand=True, padx=15, pady=10)

        buttons = tk.Frame(self.root, bg="#0f0f1a")
        buttons.pack(fill=tk.X, padx=15, pady=8)
        self.speak_btn = tk.Button(
            buttons, text="Speak (F5)", command=self.speak_ui,
            font=("Segoe UI", 12, "bold"), bg="#00ffaa", fg="#0f0f1a",
            relief=tk.FLAT, padx=22, pady=9, cursor="hand2"
        )
        self.speak_btn.pack(side=tk.LEFT, padx=4)
        tk.Button(
            buttons, text="Stop (Esc)", command=self.stop,
            font=("Segoe UI", 12, "bold"), bg="#e74c3c", fg="#ffffff",
            relief=tk.FLAT, padx=22, pady=9, cursor="hand2"
        ).pack(side=tk.LEFT, padx=4)
        tk.Button(
            buttons, text="Clear", command=self.clear, bg="#34495e", fg="#ffffff",
            relief=tk.FLAT, padx=18, pady=9, cursor="hand2"
        ).pack(side=tk.LEFT, padx=4)
        tk.Button(
            buttons, text="Paste", command=self.paste, bg="#34495e", fg="#ffffff",
            relief=tk.FLAT, padx=18, pady=9, cursor="hand2"
        ).pack(side=tk.LEFT, padx=4)

        self.status = tk.Label(
            self.root, text="Reading Windows voices...", font=("Segoe UI", 9),
            bg="#0f0f1a", fg="#a0a0a0"
        )
        self.status.pack(pady=5)
        self.root.bind("<Control-v>", lambda event: self.paste())
        self.root.bind("<F5>", lambda event: self.speak_ui())
        self.root.bind("<Escape>", lambda event: self.stop())
        self.text_box.focus_set()

    def show_ui(self, icon=None, item=None):
        self.root.after(0, self._show_ui)

    def _show_ui(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def hide_to_tray(self):
        self.root.withdraw()

    def update_trial_status(self):
        status = inspect_trial()
        if not status.allowed:
            self.expire_trial(status.state)
            return
        self.trial_status = status
        self.trial_label.config(text=f"Free trial: {format_remaining(status.remaining)} remaining")
        self.root.after(60_000, self.update_trial_status)

    def expire_trial(self, state):
        messages = {
            "clock_rollback": "Speakeasy detected that the system clock moved backward. The trial cannot continue.",
            "invalid": "The Speakeasy trial record is damaged or has been changed.",
            "storage_error": "Speakeasy could not safely read or update the trial record.",
        }
        message = messages.get(state, "Your three-day Speakeasy trial has ended.")
        messagebox.showwarning(
            "Speakeasy trial ended",
            message + "\n\nPurchase the full version to keep using Speakeasy.",
        )
        webbrowser.open(PURCHASE_URL)
        self.exit_app()

    def paste(self):
        try:
            text = self.root.clipboard_get()
            self.text_box.insert(tk.INSERT, text)
        except tk.TclError:
            pass

    def speak_ui(self):
        text = self.text_box.get("1.0", tk.END).strip()
        if text:
            self.speak_text(text)

    def speak_text(self, text):
        if not self._current_voice_id:
            self._safe_status("No Windows voice is available.", "#e74c3c")
            return
        if self.is_speaking:
            self._do_stop()
            time.sleep(0.05)
        self.is_speaking = True
        self._safe_status(f"Speaking with {self._current_voice_name}...", "#00ffaa")
        self._safe_button_state(tk.DISABLED)

        def run_speech():
            try:
                engine = pyttsx3.init(driverName="sapi5")
                with self._engine_lock:
                    self._engine = engine
                engine.setProperty("voice", self._current_voice_id)
                engine.say(text)
                engine.runAndWait()
            except Exception as error:
                self._safe_status(f"Speech error: {error}", "#e74c3c")
            finally:
                with self._engine_lock:
                    self._engine = None
                self.is_speaking = False
                self._safe_button_state(tk.NORMAL)
                self._safe_status("Ready", "#a0a0a0")

        threading.Thread(target=run_speech, daemon=True).start()

    def stop(self):
        self._do_stop()

    def _do_stop(self):
        self.is_speaking = False
        with self._engine_lock:
            engine = self._engine
        if engine:
            try:
                engine.stop()
            except Exception:
                pass
        self._safe_status("Stopped", "#e74c3c")
        self._safe_button_state(tk.NORMAL)

    def _safe_status(self, text, color):
        try:
            self.root.after(0, lambda: self.status.config(text=text, fg=color))
        except Exception:
            pass

    def _safe_button_state(self, state):
        try:
            self.root.after(0, lambda: self.speak_btn.config(state=state))
        except Exception:
            pass

    def clear(self):
        self.text_box.delete("1.0", tk.END)
        self.status.config(text="Cleared", fg="#a0a0a0")

    def exit_app(self, icon=None, item=None):
        keyboard.unhook_all()
        self._do_stop()
        if self.tray_icon:
            self.tray_icon.stop()
        self.root.destroy()


def authorize_trial():
    status = inspect_trial()
    if status.state == "not_started":
        prompt_root = tk.Tk()
        prompt_root.withdraw()
        begin = messagebox.askyesno(
            "Start your Speakeasy trial",
            "Start your free three-day Speakeasy trial now?\n\n"
            "The 72-hour trial begins when you choose Yes. There is no charge and no automatic renewal.\n\n"
            "Choose No to visit the purchase page instead.",
            parent=prompt_root,
        )
        prompt_root.destroy()
        if not begin:
            webbrowser.open(PURCHASE_URL)
            return None
        status = start_trial()
    if not status.allowed:
        prompt_root = tk.Tk()
        prompt_root.withdraw()
        messages = {
            "clock_rollback": "Speakeasy detected that the system clock moved backward. The trial cannot continue.",
            "invalid": "The Speakeasy trial record is damaged or has been changed.",
            "storage_error": "Speakeasy could not safely store its trial record.",
        }
        message = messages.get(status.state, "Your three-day Speakeasy trial has ended.")
        messagebox.showwarning(
            "Speakeasy trial unavailable",
            message + "\n\nPurchase the full version to keep using Speakeasy.",
            parent=prompt_root,
        )
        prompt_root.destroy()
        webbrowser.open(PURCHASE_URL)
        return None
    return status


if __name__ == "__main__":
    trial_status = authorize_trial()
    if trial_status:
        app = SpeakeasyTTS(trial_status)
        app.root.mainloop()
