@echo off
rem Compatibility shortcut. Open QuadraHydra.exe directly for no console flash.
start "" "%~dp0QuadraHydra.exe"
