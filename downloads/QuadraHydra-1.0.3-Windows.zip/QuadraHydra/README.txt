QuadraHydra 1.0.3 — Three-day trial
Build QH-2026-0903-002

Extract the complete ZIP and open QuadraHydra.exe. Keep all supplied files together.
Windows 10/11, 64-bit. No Python, compiler, or development environment is required.
Windows PowerShell 5.1 is used in the background. Normal launch has no terminal window.

Choose Start Trial for 72 hours, starting when you press the button. Time continues
while the app is closed. Restarting or moving this folder does not renew the trial
while its saved trial record remains present. An old seven-day record is limited
to 72 hours from its original start date in this release.

After purchase, paste the complete QH1 key into the License dialog. Paid activation
remains valid after the trial expires. SpeakEasy keys do not activate QuadraHydra.
Existing valid QH1 licenses remain valid; the signing key has not changed.

At expiry, new process modifications require activation. The existing window keeps
Resume available so you can undo a suspension; process identity checks still apply.

Settings, trial, activation, and logs are saved under:
%LOCALAPPDATA%\AveryLogicWorks\QuadraHydra

If launch fails, its message identifies the log. The diagnostics BAT intentionally
opens a visible terminal and is only for troubleshooting.

Purchase: $15 USD paid once for one PC. Each additional PC needs its own license.
The one-PC limit is contractual; this version does not bind keys to hardware.

On first launch, review and accept the included Terms and Software License.
Declining exits without starting your trial. The terms and privacy files must
stay with the app. Changed legal documents require acceptance again.

Buy or request help at https://averylogicworks.com/programs.html#quadrahydra-purchase
Payments use PayPal. The founder confirms the payment and sends your key separately.
For activation or billing help: Averylogicworks@gmail.com
