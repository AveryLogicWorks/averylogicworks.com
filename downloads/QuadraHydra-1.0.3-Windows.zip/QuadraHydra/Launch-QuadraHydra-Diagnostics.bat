@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0QuadraHydra-Start.ps1"
echo.
echo Diagnostic logs are in %%LOCALAPPDATA%%\AveryLogicWorks\QuadraHydra\Logs
pause
